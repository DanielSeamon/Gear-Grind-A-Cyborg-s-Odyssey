using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SelectionArrow : MonoBehaviour
{
    //[SerializeField] private AudioClip changeSound;
    //[SerializeField] private AudioClip interactionSound;
    [SerializeField] private RectTransform[] options;
    private int currentPosition;
    private RectTransform rect;

    private void Awake()
    {
        rect = GetComponent<RectTransform>();
    }

    private void Update()
    {
        //This code moves the selection arrow between options
        if (Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow))
        {
            ChangePosition(-1);
        }
        else if (Input.GetKeyDown(KeyCode.S) || Input.GetKeyDown(KeyCode.DownArrow))
        {
            ChangePosition(1);
        }

        // This code presses the selected option
        if (Input.GetKeyDown(KeyCode.KeypadEnter) || Input.GetKeyDown(KeyCode.E))
        {

        }
    }

    private void ChangePosition(int change)
    {
        currentPosition += change;

        /*
        if (change != 0)
        {
            SoundManager.instance.PlaySound(changeSound);
        }
        */

        if (currentPosition < 0)
        {
            currentPosition = options.Length - 1; 
        }
        else if (currentPosition > options.Length - 1)
        {
            currentPosition = 0;
        }

        rect.position = new Vector3(rect.position.x, options[currentPosition].position.y, 0);
    }

    private void Interact()
    {
        //SoundManager.instance.PlaySound(interactSound);
        options[currentPosition].GetComponent<Button>().onClick.Invoke();
    }
}
