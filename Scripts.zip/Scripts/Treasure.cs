using UnityEngine;
using UnityEngine.SceneManagement;


public class Treasure : MonoBehaviour
{
    private UIManager manager;

    private void Awake()
    {
        //currentHealth = startingHealth;
        //anim = GetComponent<Animator>();
        manager = FindObjectOfType<UIManager>();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            //SceneManager.LoadScene("Congratulations");
            //collision.GetComponent<>().TakeDamage(damage);
            manager.Victory();
        }
    }
}

