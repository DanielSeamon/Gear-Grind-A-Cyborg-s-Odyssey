using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    [SerializeField] private float speed;
    private float currentPositionX;
    private Vector3 velocity = Vector3.zero;

    [SerializeField] private Transform player;

    // Update is called once per frame
    void Update()
    {
        //Follow the player with the camera
        transform.position = new Vector3(player.position.x, player.position.y, transform.position.z);

    }
}
